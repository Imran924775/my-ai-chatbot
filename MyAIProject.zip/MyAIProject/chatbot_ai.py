import csv
import glob
import os
import re
import numpy as np
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ✅ Folder path
folder_path = "/sdcard/MyAIProject/"
csv_files = glob.glob(folder_path + "*.csv")

questions, answers = [], []

# ✅ Clean function
def clean(text):
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

# ✅ Load CSVs
for file in csv_files:
    with open(file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if len(row) >= 2:
                q = clean(row[0])
                a = row[1].strip()
                if q and a:
                    questions.append(q)
                    answers.append(a)

if not questions:
    print("⚠️ ERROR: No data found.")
    exit()

# ✅ Train vectorizer
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(questions)

# ✅ Save model
joblib.dump(vectorizer, folder_path + "vectorizer.pkl")
joblib.dump(answers, folder_path + "answers.pkl")
joblib.dump(questions, folder_path + "questions.pkl")
joblib.dump(X, folder_path + "vectors.pkl")

print("✅ Bukhari AI trained and saved!")

# ✅ Chat loop
print("\n🤖 Bukhari AI Ready! Type 'exit' to quit.\n")

while True:
    user_input = input("🧑 You: ")
    if user_input.lower() == 'exit':
        print("👋 Bye!")
        break

    cleaned_input = clean(user_input)
    if not cleaned_input:
        print("🤖 Bukhari AI: Sawal samajh nahi aaya.")
        continue

    user_vec = vectorizer.transform([cleaned_input])
    similarities = cosine_similarity(user_vec, X)[0]
    max_index = np.argmax(similarities)
    max_score = similarities[max_index]

    if max_score >= 0.3:  # adjust if needed
        print("🤖 Bukhari AI:", answers[max_index])
    else:
        print("🤖 Bukhari AI: Sorry, I didn’t understand that. Try asking something like:\n- mera whatsapp open nahi ho raha\n- mobile ka camera blur hai\n- mujhe english ka test dena hai")